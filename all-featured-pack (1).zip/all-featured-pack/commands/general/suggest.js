const { MessageEmbed } = require("discord.js")


module.exports = {
  name: "suggest",
  aliases: [],
  usage: "suggest <message>",
  description: "Send your Suggestion",
  timeout: 10000,
  run: (client, message, args) => {


    if(!args.length) {
      return message.channel.send({embed: {
        color: 10038562,
        description: "Please Give the Suggestion Channel :x: "
      }})
    }

    let channel = message.guild.channels.cache.find((x) => (x.name === "suggestion" || x.name === "suggestions"))


    if(!channel) {
      return message.channel.send({embed: {
        color: 10038562,
        description: "there is no channel with name - suggestions :x: "
      }})
    }


    let embed = new MessageEmbed()
    .setAuthor(message.author.tag, message.author.avatarURL())
    .setThumbnail(message.author.avatarURL())
    .setColor("PURPLE")
    .setDescription(`**New Suggestion!**  \n ${args.join(" ")}`)
    .setTimestamp()


    channel.send(embed).then(m => {
      m.react("👍")
      m.react("👎")
    })



    message.channel.send({embed: {
            color: 3066993,
            description : (`Success Your Suggestion has been send at:   + **${channel}**`)
          }})

  }
}
