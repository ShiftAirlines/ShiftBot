const Message  = require("discord.js")

module.exports = {
    name: 'grouplink',
    aliases: ['link'],
    description: 'gives group link ',
    run: async (client, message, args) => {
        message.reply("https://roblox.com/groups/6175043/Shift-Airlines#!/about")
 }}