const discord = require("discord.js");

module.exports = {
  name: "unban",
  description: "unban a user ",
  run: async (client, message, args) => {
  

    if(!message.member.hasPermission("BAN_MEMBERS")) {
      return msg.channel.send(`**${msg.author.username}**, You do not have perms to unban someone`)
    }
    
    if(!message.guild.me.hasPermission("BAN_MEMBERS")) {
      return msg.channel.send(`**${msg.author.username}**, I do not have perms to unban someone`)
    }
    
    let userID = args[0]
      message.guild.fetchBans().then(bans=> {
      if(bans.size == 0) return 
      let bUser = bans.find(b => b.user.id == userID)
      if(!bUser) return
      message.guild.members.unban(bUser.user)

      let ubembed = new discord.MessageEmbed()
      .setTitle("unban")
      .setDescription(`unbanned successfully`)
      .setColor("#ff2050")
      .addField(`${args[1,2,3,4,5,6,7,8,9]}`)
      .setFooter(`unbanned by ${message.author.tag}`);
       message.channel.send(ubembed)

})


  }}