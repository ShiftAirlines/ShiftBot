
const discord = require("discord.js");

module.exports = {
  name: "kick",
  description: "kick who break the rules!",
  run: async (client, message, args) => {
    if (!message.member.hasPermission("KICK_MEMBERS")) {
      return message.channel.send(`**${message.author.username}**, You do not have perms to Kick someone`);
    }

    if (!message.guild.me.hasPermission("BAN_MEMBERS")) {
      return message.channel.send(` ${message.author.name} , I do not have perms to kick someone"`
      );
    }

    const target = message.mentions.members.first();

    if (!target) {
      return message.channel.send(`**${message.author.username}**, Please mention the person who you want to kick.`
      );
    }

    if (target.id === message.author.id) {
      return message.channel.send(`**${message.author.username}**, You can not kick yourself!`
      );
    }

    if (!args[1]) {
      return message.channel.send(`**${message.author.username}**, Please Give Reason To kick Member`
      );
    }

    let embed = new discord.MessageEmbed()
      .setTitle("kick")
      .setDescription(`kicked ${target} (${target.id})`)
      .setColor("#ff2050")
      .addField(`${args[1]}`)
      .setThumbnail(target.avatarURL)
      .setFooter(`kicked by ${message.author.tag}`);

    message.channel.send(embed);
    target.kick(args[1]);
  }
};