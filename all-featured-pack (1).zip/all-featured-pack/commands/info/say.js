
const { MessageEmbed } = require('discord.js');

module.exports = {
name: 'say',
description: 'Repeats what you send/say',

run: async(client, message, args) => {
const arg = args.join(" ");
const embed = new MessageEmbed()
.setAuthor(message.author)
.setDescription(`**${arg}**`);

message.channel.send(embed)
}
} 