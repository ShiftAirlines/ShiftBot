

const { MessageEmbed } = require('discord.js')
const moment = require('moment')

module.exports = {
  name: 'botinfo',
  aliases: ['info'],
  description: 'Shows info about this bot ',
  run: async (client, message, args) => {

   
    const embed = new MessageEmbed()
    .setColor('RANDOM')
    .setAuthor(`:yellowarrow: Bot's Info`)
    .setThumbnail(client.user.displayAvatarURL())
    .addFields({
      name: 'ID',
      value: client.user.id
    }, {
      name: 'Created at',
      value: `${moment.utc(client.createdAt).format("dddd, MMMM Do YYYY")}`
    },{
        name: 'Created by',
        value:`Avia_bruno`
    },{
        name: '**Version**',
        value:'1.0.0 **Beta version**'
    },{
                    name: '🌐 Servers',
                    value: `Serving ${client.guilds.cache.size} servers.`,
                    inline: true
},{
                    name: '👥 Server Users',
                    value: `Serving ${client.users.cache.size}`,
                    inline: true
                     }, )
    .setFooter(`requested by ${message.author.tag}`)
    .setTimestamp()

    
    const member = message.guild.members.cache.get(client.user.id)

    if (member) {
      embed.addField('Joined At', `${moment.utc(member.joinedAt).format("dddd, MMMM Do YYYY")}`)
      embed.addField('Roles:', member.roles.cache.map(r => `<@&${r.id}>`).join(' | '))
    }

    message.channel.send(embed)
  }
}