const {Collection, Client, } = require('discord.js')
const fs = require('fs')
const client = new Client({
    disableEveryone: true
})

const {GiveawaysManager} = require("discord-giveaways")
const mongoose = require("mongoose");

mongoose.connect('mongodb+srv://james:james123@cluster0.514w6.mongodb.net/Data', {
  useUnifiedTopology : true,
  useNewUrlParser : true,

}).then(console.log("connected to mongo database"))

client.giveaways = new GiveawaysManager(client,{
  storage : './giveaways.json',
  updateCountdownEvery : 5000,
  embedColor : 'RANDOM',
  reaction : '🎉'
})

const Discord = require('discord.js')
const config = require('./config.json')
const prefix = config.prefix
const token = config.token
client.commands = new Collection();
client.aliases = new Collection();
client.categories = fs.readdirSync("./commands/");
["command"].forEach(handler => {
    require(`./handlers/${handler}`)(client); 
}); 
client.on('ready', () => {
    client.user.setActivity(`${prefix}help`)
    console.log(`${client.user.username} ✅`)
})
client.on('message', async message =>{
    if(message.author.bot) return;
    if(!message.content.startsWith(prefix)) return;
    if(!message.guild) return;
    if(!message.member) message.member = await message.guild.fetchMember(message);
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();
    if(cmd.length == 0 ) return;
    let command = client.commands.get(cmd)
    if(!command) command = client.commands.get(client.aliases.get(cmd));
    if(command) command.run(client, message, args) 
});




client.on("guildMemberAdd", member => {
  let channel = client.channels.cache.get("706938917206622308");

  

    let embed = new Discord.MessageEmbed()
    .setColor("#411459")
    .setTitle(`**Welcome**`)
    .setDescription(
      `**Welcome ${member.user.tag}**! **We're glad to have you with us at Shift Airlines.**` )
    .setImage("https://cdn.discordapp.com/attachments/796645710572945418/796650411535630336/unknown.png")
    .setTimestamp()
  channel.send(embed);
}); 

client.login(token)
